import CoreLocation
import MapKit
import SwiftUI
import UIKit

struct ContentView: View {
    @StateObject private var locationManager = LocationManager()

    var body: some View {
        TabView {
            NavigationStack {
                HomeView()
            }
            .tabItem {
                Label("Home", systemImage: "house.fill")
            }

            NavigationStack {
                SearchView()
            }
            .tabItem {
                Label("Search", systemImage: "magnifyingglass")
            }

            NavigationStack {
                if let emergency = GuideData.sections.first(where: { $0.id == "emergency" }) {
                    SectionDetailView(section: emergency)
                }
            }
            .tabItem {
                Label("Urgent", systemImage: "exclamationmark.triangle.fill")
            }
        }
        .tint(Color.navy)
        .onAppear {
            locationManager.requestLocationPermission()
        }
    }
}

struct HomeView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                header
                sections
                disclaimer
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 28)
        }
        .background(Color.page)
        .toolbar(.hidden, for: .navigationBar)
    }

    private var header: some View {
        VStack(spacing: 12) {
            LogoImage()
                .frame(width: 300, height: 300)
                .clipShape(RoundedRectangle(cornerRadius: 58, style: .continuous))
                .shadow(color: Color.navy.opacity(0.15), radius: 24, x: 0, y: 12)
                .padding(.top, 10)

            Text("JULY 2026")
                .font(.caption.weight(.bold))
                .tracking(4)
                .foregroundStyle(Color.teal)

            Text("A practical guide for visiting boaters: fuel, local services, food, transport and useful numbers around the marina.")
                .font(.body)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
    }

    private var sections: some View {
        VStack(alignment: .leading, spacing: 10) {
            ForEach(GuideData.sections) { section in
                NavigationLink {
                    SectionDetailView(section: section)
                } label: {
                    SectionRow(section: section)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var disclaimer: some View {
        Text("Produced independently by 88 London Ltd for visiting boaters. This guide is not produced by, endorsed by or affiliated with St Katharine Docks Marina. Information is provided in good faith and should be checked directly with each provider.")
            .font(.caption)
            .foregroundStyle(.secondary)
            .padding(.top, 6)
    }
}

struct SearchView: View {
    @State private var searchText = ""

    private var results: [(GuideSection, GuideEntry)] {
        let needle = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !needle.isEmpty else { return [] }

        return GuideData.sections.flatMap { section in
            section.entries.compactMap { entry in
                let haystack = "\(section.title) \(entry.title) \(entry.meta) \(entry.body)".lowercased()
                return haystack.contains(needle) ? (section, entry) : nil
            }
        }
    }

    var body: some View {
        List {
            if searchText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Text("Start typing to search the guide.")
                    .foregroundStyle(.secondary)
            } else if results.isEmpty {
                Text("No matches found.")
                    .foregroundStyle(.secondary)
            } else {
                ForEach(results, id: \.1.id) { section, entry in
                    NavigationLink {
                        SectionDetailView(section: section)
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(entry.title)
                                .font(.headline)
                                .foregroundStyle(Color.navy)
                            Text("\(section.title) - \(entry.meta)")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .navigationTitle("Search")
        .searchable(text: $searchText, prompt: "Try fuel, pharmacy, pub or taxi")
    }
}

struct LogoImage: View {
    var body: some View {
        if let path = Bundle.main.path(forResource: "around-docks-logo", ofType: "png"),
           let image = UIImage(contentsOfFile: path) {
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
        } else {
            ZStack {
                Color.white
                VStack(spacing: 8) {
                    Image(systemName: "sailboat.fill")
                        .font(.largeTitle)
                        .foregroundStyle(Color.teal)
                }
            }
        }
    }
}

struct SectionDetailView: View {
    let section: GuideSection

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(section.intro)
                    .font(.body)
                    .foregroundStyle(.secondary)

                VStack(spacing: 10) {
                    ForEach(section.entries) { entry in
                        EntryCard(entry: entry, mapPlace: mapPlace(for: entry))
                    }
                }

                if section.id == "fuel" {
                    Text("For red diesel bookings or local boat support, 88 London Ltd is the simplest first call: 07733 371641.")
                        .font(.callout.weight(.semibold))
                        .foregroundStyle(Color.navy)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.gold.opacity(0.14))
                        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                }

                SectionMapView(section: section)
                    .frame(height: 260)
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            }
            .padding(18)
        }
        .background(Color.page)
        .navigationTitle(section.title)
        .navigationBarTitleDisplayMode(.large)
    }

    private func mapPlace(for entry: GuideEntry) -> GuidePlace? {
        if let exact = section.places.first(where: { $0.name.localizedCaseInsensitiveCompare(entry.title) == .orderedSame }) {
            return exact
        }

        switch entry.title {
        case "88 London Ltd":
            return section.places.first(where: { $0.name.localizedCaseInsensitiveContains("88 London") })
        case "Marine engineers and boatyard":
            return section.places.first(where: { $0.name == "South Dock Marina" })
        default:
            return nil
        }
    }
}

struct SectionMapView: View {
    let section: GuideSection
    @State private var position: MapCameraPosition

    init(section: GuideSection) {
        self.section = section
        _position = State(initialValue: .region(Self.region(for: section.places)))
    }

    var body: some View {
        Map(position: $position) {
            Marker(GuideData.home.name, systemImage: "sailboat.fill", coordinate: GuideData.home.coordinate)
                .tint(Color.navy)

            ForEach(section.places) { place in
                Marker(place.name, coordinate: place.coordinate)
                    .tint(place.name.contains("88 London") ? Color.gold : Color.teal)
            }

            UserAnnotation()
        }
        .mapControls {
            MapUserLocationButton()
            MapCompass()
            MapScaleView()
        }
    }

    private static func region(for places: [GuidePlace]) -> MKCoordinateRegion {
        let allPlaces = [GuideData.home] + places
        let latitudes = allPlaces.map(\.latitude)
        let longitudes = allPlaces.map(\.longitude)
        let minLatitude = latitudes.min() ?? GuideData.home.latitude
        let maxLatitude = latitudes.max() ?? GuideData.home.latitude
        let minLongitude = longitudes.min() ?? GuideData.home.longitude
        let maxLongitude = longitudes.max() ?? GuideData.home.longitude
        let latitudeDelta = max(0.012, (maxLatitude - minLatitude) * 1.7)
        let longitudeDelta = max(0.012, (maxLongitude - minLongitude) * 1.7)

        return MKCoordinateRegion(
            center: CLLocationCoordinate2D(
                latitude: (minLatitude + maxLatitude) / 2,
                longitude: (minLongitude + maxLongitude) / 2
            ),
            span: MKCoordinateSpan(latitudeDelta: latitudeDelta, longitudeDelta: longitudeDelta)
        )
    }
}

struct EntryCard: View {
    let entry: GuideEntry
    let mapPlace: GuidePlace?

    private let linkColumns = [
        GridItem(.adaptive(minimum: 118), spacing: 8)
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack(alignment: .leading, spacing: 4) {
                Text(entry.title)
                    .font(.headline)
                    .foregroundStyle(Color.navy)
                Text(entry.meta)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Text(entry.body)
                .font(.body)
                .foregroundStyle(.primary)

            LazyVGrid(columns: linkColumns, alignment: .leading, spacing: 8) {
                if let phone = entry.phone, let url = URL(string: "tel:\(phone)") {
                    Link(destination: url) {
                        Label("Call", systemImage: "phone.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(CompactButtonStyle(filled: true))
                }

                if let mapPlace {
                    Link(destination: mapPlace.mapsURL) {
                        Label("Map", systemImage: "map.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(CompactButtonStyle(filled: false))
                }

                ForEach(entry.links) { link in
                    Link(destination: link.url) {
                        Text(link.title)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(CompactButtonStyle(filled: false))
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
    }
}

struct SectionRow: View {
    let section: GuideSection

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: section.symbol)
                .font(.title3)
                .foregroundStyle(section.featured ? Color.white : Color.teal)
                .frame(width: 44, height: 44)
                .background(section.featured ? Color.navy : Color.aqua)
                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))

            VStack(alignment: .leading, spacing: 4) {
                Text(section.title)
                    .font(.headline)
                    .foregroundStyle(Color.navy)
                Text(section.teaser)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }

            Spacer()
            Image(systemName: "chevron.right")
                .font(.footnote.weight(.bold))
                .foregroundStyle(Color.gold)
        }
        .padding()
        .background(section.featured ? Color.gold.opacity(0.13) : Color.white)
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .stroke(section.featured ? Color.gold.opacity(0.35) : Color.black.opacity(0.08))
        )
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundStyle(.white)
            .padding(.vertical, 15)
            .background(Color.navy.opacity(configuration.isPressed ? 0.85 : 1))
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
    }
}

struct SecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundStyle(Color.navy)
            .padding(.vertical, 15)
            .background(configuration.isPressed ? Color.aqua : Color.white)
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .stroke(Color.black.opacity(0.08))
            )
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
    }
}

struct CompactButtonStyle: ButtonStyle {
    let filled: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(filled ? Color.white : Color.navy)
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .background(filled ? Color.teal : Color.aqua.opacity(configuration.isPressed ? 0.7 : 1))
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
    }
}

final class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()

    override init() {
        super.init()
        manager.delegate = self
    }

    func requestLocationPermission() {
        manager.requestWhenInUseAuthorization()
    }
}

extension Color {
    static let navy = Color(red: 13 / 255, green: 43 / 255, blue: 78 / 255)
    static let teal = Color(red: 47 / 255, green: 133 / 255, blue: 141 / 255)
    static let aqua = Color(red: 228 / 255, green: 244 / 255, blue: 244 / 255)
    static let gold = Color(red: 198 / 255, green: 154 / 255, blue: 51 / 255)
    static let page = Color(red: 247 / 255, green: 250 / 255, blue: 249 / 255)
}
