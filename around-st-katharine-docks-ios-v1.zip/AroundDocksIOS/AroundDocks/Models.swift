import CoreLocation
import Foundation

struct GuideSection: Identifiable, Hashable {
    let id: String
    let title: String
    let symbol: String
    let teaser: String
    let intro: String
    let featured: Bool
    let entries: [GuideEntry]
    let places: [GuidePlace]
}

struct GuideEntry: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let meta: String
    let body: String
    let phone: String?
    let links: [GuideLink]
}

struct GuideLink: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let url: URL
}

struct GuidePlace: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let subtitle: String
    let latitude: CLLocationDegrees
    let longitude: CLLocationDegrees
    let websiteURL: URL?

    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }

    var mapsURL: URL {
        let query = name.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? name
        return URL(string: "http://maps.apple.com/?q=\(query)&ll=\(latitude),\(longitude)")!
    }
}

enum GuideData {
    static let home = GuidePlace(
        name: "St Katharine Docks Marina",
        subtitle: "Current marina area",
        latitude: 51.50667353386603,
        longitude: -0.07145119299494501,
        websiteURL: URL(string: "https://www.skdocks.co.uk")
    )

    static let sections: [GuideSection] = [
        GuideSection(
            id: "fuel",
            title: "Fuel & Boat Support",
            symbol: "fuelpump.fill",
            teaser: "Red diesel, local fuel options, engineers and practical help.",
            intro: "Fuel and practical support for visiting boats, with 88 London as the first point of contact for red diesel bookings, minor repairs and local parts advice.",
            featured: true,
            entries: [
                GuideEntry(
                    title: "88 London Ltd",
                    meta: "Fuel bookings, assistance and minor repairs",
                    body: "Gas oil / red diesel is available from the fuel barge on the north side of the Thames, just below London Bridge. Call 88 London Ltd to book. Larger quantities may be delivered to the marina by bunker barge, subject to availability, so it is best to arrange this early.",
                    phone: "+447733371641",
                    links: [web("Message", "sms:+447733371641"), web("Website", "https://88-london.com")]
                ),
                GuideEntry(
                    title: "Jet Service Station",
                    meta: "Road diesel, petrol and engine oil on The Highway",
                    body: "A nearby filling station option for road diesel, petrol and engine oil when carrying fuel or supplies by hand. 88 London may be able to help with advice if you are not familiar with the area.",
                    phone: nil,
                    links: [web("Website", "https://www.jetlocal.co.uk")]
                ),
                GuideEntry(
                    title: "Texaco Service Station",
                    meta: "Road diesel, petrol and engine oil on The Highway",
                    body: "Another nearby filling station on The Highway for road diesel, petrol and engine oil.",
                    phone: nil,
                    links: [web("Website", "https://texaco.co.uk")]
                ),
                GuideEntry(
                    title: "Chandlery",
                    meta: "Order online for marina delivery",
                    body: "There are no local chandlery shops close to the docks. For chandlery items, ordering online for delivery is usually the simplest option.",
                    phone: nil,
                    links: [web("ASAP Supplies", "https://www.asap-supplies.com")]
                ),
                GuideEntry(
                    title: "Screwfix Whitechapel",
                    meta: "Tools and consumables",
                    body: "A useful nearby option for tools, fixings, electrical items, plumbing parts, sealants and other repair basics.",
                    phone: nil,
                    links: [web("Website", "https://www.screwfix.com")]
                ),
                GuideEntry(
                    title: "Toolstation Bermondsey",
                    meta: "Tools and consumables",
                    body: "A practical option for tools, fasteners, electrical items and general workshop consumables south of the river.",
                    phone: nil,
                    links: [web("Website", "https://www.toolstation.com")]
                ),
                GuideEntry(
                    title: "Leyland SDM Shoreditch",
                    meta: "Decorating, hardware and maintenance supplies",
                    body: "A useful local supplier for decorating materials, hardware, adhesives, sealants and maintenance items.",
                    phone: nil,
                    links: [web("Website", "https://leylandsdm.co.uk")]
                ),
                GuideEntry(
                    title: "Marine engineers and boatyard",
                    meta: "South Dock Marina and local contacts",
                    body: "South Dock Marina has a boatyard with a 20 ton crane and may be able to recommend local engineers. 88 London can also help with minor repairs and sourcing mechanical parts.",
                    phone: nil,
                    links: [web("South Dock Marina", "https://www.southwark.gov.uk/culture-and-sport/south-dock-marina")]
                ),
                GuideEntry(
                    title: "Marine surveyors",
                    meta: "GPV Marine - Paul Hastings",
                    body: "GPV Marine provides marine surveying services and is a useful contact for owners needing survey support locally.",
                    phone: nil,
                    links: [web("Website", "https://gpvmarinesurveys.com")]
                )
            ],
            places: [
                place("88 London fuel barge", "Red diesel bookings", 51.508403124009774, -0.08574198333246075, "https://88-london.com"),
                place("Jet Service Station", "The Highway", 51.50931622800538, -0.060910111638220014, "https://www.jetlocal.co.uk"),
                place("Texaco Service Station", "The Highway", 51.50944476955662, -0.06393296117569074, "https://texaco.co.uk"),
                place("Screwfix Whitechapel", "Tools and consumables", 51.51479368250332, -0.06607420455553815, "https://www.screwfix.com"),
                place("Toolstation Bermondsey", "Tools and consumables", 51.489237235101456, -0.056216767363146826, "https://www.toolstation.com"),
                place("Leyland SDM Shoreditch", "Decorating and hardware", 51.52321877920903, -0.07794873154213633, "https://leylandsdm.co.uk"),
                place("South Dock Marina", "Boatyard and 20T crane", 51.49411099494587, -0.03345447202440098, "https://www.southwark.gov.uk/culture-and-sport/south-dock-marina")
            ]
        ),
        GuideSection(
            id: "moorings",
            title: "Visitor Moorings",
            symbol: "sailboat.fill",
            teaser: "Nearby alternatives if you need another berth.",
            intro: "Alternative visitor moorings nearby. As with St Katharine Docks, access is generally around high water, so check timings and availability before committing.",
            featured: false,
            entries: [
                GuideEntry(
                    title: "Hermitage Community Moorings",
                    meta: "Visitor berths near Tower Bridge",
                    body: "A visitor mooring very near St Katharine Docks, directly on the Thames by Tower Bridge.",
                    phone: nil,
                    links: [web("Website", "https://www.hermitagemoorings.com/hrp/visitor-berths/")]
                ),
                GuideEntry(
                    title: "South Dock Marina",
                    meta: "Marina, boatyard and 20T crane in Rotherhithe",
                    body: "A practical alternative with marina facilities, a boatyard and a 20 ton crane.",
                    phone: nil,
                    links: [web("Website", "https://www.southwark.gov.uk/culture-and-sport/south-dock-marina")]
                ),
                GuideEntry(
                    title: "Limehouse Marina",
                    meta: "Aquavista marina east of St Katharine Docks",
                    body: "Another established marina option on the Thames.",
                    phone: nil,
                    links: [web("Website", "https://www.aquavista.com/find-a-marina/limehouse-waterside-marina")]
                )
            ],
            places: [
                place("Hermitage Community Moorings", "On the Thames by Tower Bridge", 51.50352526066546, -0.06624423819776121, "https://www.hermitagemoorings.com/hrp/visitor-berths/"),
                place("South Dock Marina", "Marina and 20T crane", 51.49411099494587, -0.03345447202440098, "https://www.southwark.gov.uk/culture-and-sport/south-dock-marina"),
                place("Limehouse Marina", "Aquavista marina", 51.51011276099087, -0.0366422754429162, "https://www.aquavista.com/find-a-marina/limehouse-waterside-marina")
            ]
        ),
        GuideSection(
            id: "looking-good",
            title: "Looking Good",
            symbol: "sparkles",
            teaser: "Hair, beauty, dry cleaning and laundry nearby.",
            intro: "Useful local services when you want to feel less like you have just crossed the tideway.",
            featured: false,
            entries: [
                GuideEntry(title: "John Hardy", meta: "Ladies hair salon in St Katharine Docks", body: "A convenient hair salon within the marina area.", phone: nil, links: [web("Website", "https://www.johnhardinghairdresserslondon.co.uk/")]),
                GuideEntry(title: "The Ivy Hair & Beauty", meta: "Unisex hairdresser near Waitrose", body: "A nearby unisex hair and beauty option close to the docks.", phone: nil, links: [web("Website", "https://www.theivyhairandbeauty.co.uk")]),
                GuideEntry(title: "Lagoon Dry Cleaners", meta: "Dry cleaning in St Katharine Docks", body: "Local dry cleaning and laundry support within the marina.", phone: nil, links: [web("Website", "https://www.lagoondrycleaners.co.uk")])
            ],
            places: [
                place("John Hardy", "Hair salon", 51.507229888816674, -0.07169017033220625, "https://www.johnhardinghairdresserslondon.co.uk/"),
                place("The Ivy Hair & Beauty", "Hair and beauty", 51.5073651051516, -0.06762584503656602, "https://www.theivyhairandbeauty.co.uk"),
                place("Lagoon Dry Cleaners", "Dry cleaning", 51.50690436174608, -0.07260354503661937, "https://www.lagoondrycleaners.co.uk")
            ]
        ),
        GuideSection(
            id: "food",
            title: "Eating & Drinking",
            symbol: "fork.knife",
            teaser: "Provisions, restaurants and historic pubs.",
            intro: "The marina has plenty to offer in the way of food and drink. If you're looking for provisions or somewhere else to eat there is plenty on offer within a short walk of the dock.",
            featured: false,
            entries: [
                GuideEntry(title: "Waitrose St Katharine Docks", meta: "Provisions", body: "A convenient supermarket for provisions close to the marina.", phone: nil, links: [web("Website", "https://www.waitrose.com")]),
                GuideEntry(title: "Tesco Express St Katharine's Way", meta: "Provisions - open late", body: "A quick nearby option for everyday groceries and essentials. Open late.", phone: nil, links: [web("Website", "https://www.tesco.com")]),
                GuideEntry(title: "Sainsbury's Local London Dock", meta: "Provisions - open late", body: "A nearby local supermarket option at London Dock. Open late.", phone: nil, links: [web("Website", "https://www.sainsburys.co.uk")]),
                GuideEntry(title: "Smiths of Wapping", meta: "Restaurant", body: "A real treat! Fantastic local restaurant that specialises in fish but has great meat and vegetarian options.", phone: nil, links: [web("Website", "https://smithsrestaurants.com/restaurant/smiths-of-wapping/")]),
                GuideEntry(title: "The Empress", meta: "Indian restaurant", body: "Traditional Indian Restaurant nearby. Eat in or Take Away.", phone: nil, links: [web("Website", "https://theempress.co.uk")]),
                GuideEntry(title: "Ektara", meta: "Indian restaurant", body: "Indian Restaurant. Authentic Indian food.", phone: nil, links: [web("Website", "https://ektara.uk")]),
                GuideEntry(title: "Rasoi Ghar", meta: "Indian restaurant", body: "Traditional Indian Restaurant nearby. Eat in or Take Away.", phone: nil, links: [web("Website", "https://rasoighar.co.uk")]),
                GuideEntry(title: "River View", meta: "Chinese restaurant", body: "A Chinese restaurant on the riverside at New Crane Wharf. Eat in or Take Away.", phone: nil, links: [web("Website", "https://riverview-restaurant.com")]),
                GuideEntry(title: "The Dickens Inn", meta: "Pub at St Katharine Docks", body: "The obvious pub inside the dock, easy to find and useful for visitors staying in the marina.", phone: nil, links: [web("Website", "https://www.dickensinn.co.uk")]),
                GuideEntry(title: "The Town of Ramsgate", meta: "Historic Wapping pub", body: "A classic Wapping pub with strong river history, within walking distance east of the dock. Good pub food.", phone: nil, links: [web("Website", "https://townoframsgate.pub")]),
                GuideEntry(title: "Turner's Old Star", meta: "Wapping pub", body: "A nearby Wapping pub and a useful stop on a walk east from the marina. Location for 'The Krays' fight scene!", phone: nil, links: [web("Website", "https://www.turnersoldstar.co.uk")]),
                GuideEntry(title: "Captain Kidd", meta: "Samuel Smiths pub", body: "A riverside Samuel Smiths pub in Wapping, useful as part of a river walk.", phone: nil, links: [web("Website", "https://www.samuelsmithsbrewery.co.uk")]),
                GuideEntry(title: "Prospect of Whitby", meta: "Historic riverside pub", body: "Built in 1520, the Prospect of Whitby is one of London's best-known historic riverside pubs, further east along the Thames path.", phone: nil, links: [web("Website", "https://www.greeneking.co.uk/pubs/greater-london/prospect-of-whitby")]),
                GuideEntry(title: "The Moretown Belle", meta: "Modern sports bar", body: "A modern sports-bar. Plenty of screens, pool tables and darts boards. Good for pub food.", phone: nil, links: [web("Website", "https://www.bellepubsandrestaurants.co.uk/moretownbelle")])
            ],
            places: [
                place("Waitrose St Katharine Docks", "Provisions", 51.50696552873949, -0.0672418027075946, "https://www.waitrose.com"),
                place("Tesco Express St Katharine's Way", "Provisions", 51.507289616216234, -0.07390721257036746, "https://www.tesco.com"),
                place("Sainsbury's Local London Dock", "Provisions", 51.50925564556648, -0.0671458518113428, "https://www.sainsburys.co.uk"),
                place("Smiths of Wapping", "Restaurant", 51.50436628872242, -0.06619427572067478, "https://smithsrestaurants.com/restaurant/smiths-of-wapping/"),
                place("The Empress", "Indian restaurant", 51.51144022963472, -0.06840674503637596, "https://theempress.co.uk"),
                place("Ektara", "Indian restaurant", 51.503312204276845, -0.0597637450368144, "https://ektara.uk"),
                place("Rasoi Ghar", "Indian restaurant", 51.511624192258466, -0.06850511620085895, "https://rasoighar.co.uk"),
                place("River View", "Chinese restaurant", 51.50552764263207, -0.054277116201204074, "https://riverview-restaurant.com"),
                place("The Dickens Inn", "Pub at St Katharine Docks", 51.50688955033874, -0.0701937027075805, "https://www.dickensinn.co.uk"),
                place("The Town of Ramsgate", "Historic Wapping pub", 51.503503550156815, -0.06199117387226911, "https://townoframsgate.pub"),
                place("Turner's Old Star", "Wapping pub", 51.50547994273683, -0.05936334503666804, "https://www.turnersoldstar.co.uk"),
                place("Captain Kidd", "Samuel Smiths pub", 51.503512347061665, -0.05797984503678165, "https://www.samuelsmithsbrewery.co.uk"),
                place("Prospect of Whitby", "Historic riverside pub", 51.507166139030225, -0.051078316201107775, "https://www.greeneking.co.uk/pubs/greater-london/prospect-of-whitby"),
                place("The Moretown Belle", "Modern sports bar", 51.507323171909945, -0.06741923154306613, "https://www.bellepubsandrestaurants.co.uk/moretownbelle")
            ]
        ),
        GuideSection(
            id: "entertainment",
            title: "Entertainment",
            symbol: "binoculars.fill",
            teaser: "Attractions, riverside walks and local history.",
            intro: "St Katharine Docks is a strong starting point for London sights, riverside walks and historic pubs on both sides of the Thames.",
            featured: false,
            entries: [
                GuideEntry(title: "Tower of London", meta: "Historic attraction", body: "One of London's best-known landmarks and an easy walk from St Katharine Docks.", phone: nil, links: [web("Website", "https://www.hrp.org.uk/tower-of-london/")]),
                GuideEntry(title: "Tower Bridge", meta: "London landmark", body: "The bridge beside the dock is a major London landmark and a useful crossing point for south-bank walks.", phone: nil, links: [web("Website", "https://www.towerbridge.org.uk")]),
                GuideEntry(title: "The Mayflower", meta: "Rotherhithe pub", body: "A historic riverside pub across the river in Rotherhithe. A must for American visitors.", phone: nil, links: [web("Website", "https://www.mayflowerpub.co.uk")]),
                GuideEntry(title: "The Angel", meta: "Rotherhithe pub", body: "A riverside pub in Rotherhithe, useful on a walk east along the south bank.", phone: nil, links: [web("Website", "https://www.samuelsmithsbrewery.co.uk")]),
                GuideEntry(title: "The Grapes", meta: "Limehouse pub", body: "A historic riverside pub in Limehouse, further east along the Thames corridor.", phone: nil, links: [web("Website", "https://thegrapes.co.uk")]),
                GuideEntry(title: "Brunel Museum", meta: "Local history", body: "A small museum in Rotherhithe focused on Brunel and the Thames Tunnel.", phone: nil, links: [web("Website", "https://thebrunelmuseum.com")])
            ],
            places: [
                place("Tower of London", "Historic attraction", 51.50817914844909, -0.07594930270752263, "https://www.hrp.org.uk/tower-of-london/"),
                place("Tower Bridge", "London landmark", 51.50560996688126, -0.075356502707671, "https://www.towerbridge.org.uk"),
                place("The Mayflower", "Rotherhithe pub", 51.50186698615495, -0.053563658530458656, "https://www.mayflowerpub.co.uk"),
                place("The Angel", "Rotherhithe pub", 51.50076433186253, -0.059015816201445526, "https://www.samuelsmithsbrewery.co.uk"),
                place("The Grapes", "Limehouse pub", 51.50903987579155, -0.03389534318808949, "https://thegrapes.co.uk"),
                place("Brunel Museum", "Local history", 51.501751258510886, -0.052812358530433354, "https://thebrunelmuseum.com")
            ]
        ),
        GuideSection(
            id: "transport",
            title: "Transport",
            symbol: "tram.fill",
            teaser: "Tube, buses, river boats, trains and taxis.",
            intro: "St Katharine Docks is well placed for getting around London by tube, bus, river boat, taxi and train.",
            featured: false,
            entries: [
                GuideEntry(title: "Tower Hill Station", meta: "London Underground", body: "The nearest tube station to St Katharine Docks and the most useful starting point for Underground journeys.", phone: nil, links: [web("TfL", "https://tfl.gov.uk")]),
                GuideEntry(title: "Tower Gateway DLR", meta: "Docklands Light Railway", body: "The nearest DLR station, useful for Canary Wharf, Greenwich connections and east London routes.", phone: nil, links: [web("TfL", "https://tfl.gov.uk")]),
                GuideEntry(title: "Wapping Overground", meta: "London Overground", body: "The nearest Overground station, useful for routes through east and south London.", phone: nil, links: [web("TfL", "https://tfl.gov.uk")]),
                GuideEntry(title: "Elephant Gate bus stop", meta: "Local buses", body: "A local bus stop by the dock entrance for the 100 bus towards St Paul's. More routes leave from around Tower Hill.", phone: nil, links: [web("TfL buses", "https://tfl.gov.uk/modes/buses/")]),
                GuideEntry(title: "Tower Pier", meta: "Uber Boat by Thames Clippers", body: "Uber Boat services leave from Tower Pier and are a quick way to travel through London by river.", phone: nil, links: [web("Website", "https://www.thamesclippers.com")]),
                GuideEntry(title: "Tower Hotel taxi rank", meta: "Black taxis", body: "Black taxis are a safe and trusted way to get around London, with a taxi rank outside The Tower Hotel.", phone: nil, links: [web("TfL taxis", "https://tfl.gov.uk/modes/taxis-and-minicabs/")]),
                GuideEntry(title: "Victoria Coach Station", meta: "National coaches", body: "The main London coach station for longer-distance coach travel. Many services also stop elsewhere as they pass through London.", phone: nil, links: [web("Website", "https://www.nationalexpress.com/en/help/coach-stations/london-victoria")]),
                GuideEntry(title: "Mainline rail", meta: "London terminal stations", body: "London has multiple mainline terminal stations serving different parts of the UK. Check National Rail before travelling, as the best station depends on your destination.", phone: nil, links: [web("National Rail", "https://www.nationalrail.co.uk")]),
                GuideEntry(title: "Journey planning", meta: "Citymapper", body: "Citymapper is useful for planning routes across London by tube, bus, river boat, train and walking.", phone: nil, links: [web("Citymapper", "https://citymapper.com/london")])
            ],
            places: [
                place("Tower Hill Station", "London Underground", 51.510219364445994, -0.07508700538777027, "https://tfl.gov.uk"),
                place("Tower Gateway DLR", "Docklands Light Railway", 51.51037743373488, -0.07449559235598507, "https://tfl.gov.uk"),
                place("Wapping Overground", "London Overground", 51.504412685986686, -0.055993258530276785, "https://tfl.gov.uk"),
                place("Elephant Gate bus stop", "Local buses", 51.508334656065486, -0.07094250924477537, "https://tfl.gov.uk/modes/buses/"),
                place("Tower Pier", "Uber Boat by Thames Clippers", 51.507687949999564, -0.0790603167557098, "https://www.thamesclippers.com"),
                place("Tower Hotel taxi rank", "Black taxis", 51.50626557115492, -0.07294488009192142, "https://tfl.gov.uk/modes/taxis-and-minicabs/"),
                place("Victoria Coach Station", "National coaches", 51.49254075297738, -0.1481624701198463, "https://www.nationalexpress.com/en/help/coach-stations/london-victoria")
            ]
        ),
        GuideSection(
            id: "medical",
            title: "Medical & Pharmacy",
            symbol: "cross.case.fill",
            teaser: "GP surgery and nearby pharmacy.",
            intro: "Local medical and pharmacy contacts for non-emergency help.",
            featured: false,
            entries: [
                GuideEntry(title: "St Katharine's Practice", meta: "GP surgery on Thomas More Street", body: "A local GP surgery close to St Katharine Docks.", phone: nil, links: [web("Website", "https://www.stkatharinedocks.nhs.uk/")]),
                GuideEntry(title: "City Dock Pharmacy", meta: "Pharmacy on Nesham Street", body: "A nearby pharmacy for prescriptions, medicines and health essentials.", phone: nil, links: [web("Website", "https://www.citydockpharmacy.co.uk")])
            ],
            places: [
                place("St Katharine's Practice", "GP surgery", 51.507342794235775, -0.06831275853013474, "https://www.stkatharinedocks.nhs.uk/"),
                place("City Dock Pharmacy", "Pharmacy", 51.507626447096015, -0.06648555856262968, "https://www.citydockpharmacy.co.uk")
            ]
        ),
        GuideSection(
            id: "emergency",
            title: "Emergencies",
            symbol: "exclamationmark.triangle.fill",
            teaser: "Immediate numbers and marine contacts.",
            intro: "Key numbers for urgent situations. In an emergency, call 999 first.",
            featured: false,
            entries: [
                GuideEntry(title: "Emergency services", meta: "Fire, police, ambulance and coastguard", body: "Call 999 for fire, police, ambulance or coastguard.", phone: nil, links: []),
                GuideEntry(title: "St Katharine Docks Security", meta: "Marina security", body: "Contact dock security for urgent marina-side help.", phone: "+442072645296", links: [web("Marina website", "https://www.skdocks.co.uk")]),
                GuideEntry(title: "Port of London Authority", meta: "VHF Ch14 or phone", body: "Contact the Port of London Authority on VHF Ch14 or by phone.", phone: "+442032607711", links: [web("Website", "https://www.pla.co.uk")])
            ],
            places: [
                place("St Katharine Docks Security", "Marina security", 51.507166054776555, -0.07358180289197225, "https://www.skdocks.co.uk"),
                place("Port of London Authority", "VHF Ch14", 51.49510397313468, 0.04167648940715181, "https://www.pla.co.uk")
            ]
        )
    ]

    static func web(_ title: String, _ urlString: String) -> GuideLink {
        GuideLink(title: title, url: URL(string: urlString)!)
    }

    static func place(_ name: String, _ subtitle: String, _ latitude: CLLocationDegrees, _ longitude: CLLocationDegrees, _ website: String? = nil) -> GuidePlace {
        GuidePlace(name: name, subtitle: subtitle, latitude: latitude, longitude: longitude, websiteURL: website.flatMap(URL.init(string:)))
    }
}
