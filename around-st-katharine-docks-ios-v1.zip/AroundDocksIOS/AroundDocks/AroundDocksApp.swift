import SwiftUI

@main
struct AroundDocksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
